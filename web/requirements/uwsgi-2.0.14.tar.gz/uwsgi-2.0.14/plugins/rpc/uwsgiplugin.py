NAME='rpc'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['rpc_plugin']
